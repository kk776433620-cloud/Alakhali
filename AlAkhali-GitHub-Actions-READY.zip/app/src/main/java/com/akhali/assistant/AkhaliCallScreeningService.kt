package com.akhali.assistant

import android.telecom.CallScreeningService
import android.telecom.Call.Details

class AkhaliCallScreeningService : CallScreeningService() {
    override fun onScreenCall(callDetails: Details) {
        // لاحقاً: مطابقة الرقم مع جهات الاتصال وتطبيق قواعد المستخدم.
        respondToCall(callDetails, CallResponse.Builder().setDisallowCall(false).setRejectCall(false).setSilenceCall(false).build())
    }
}
