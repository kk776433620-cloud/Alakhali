package com.akhali.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * مستمع صوتي تجريبي يعمل في المقدمة. يفضل on-device ASR عندما يدعمه الجهاز.
 * التشغيل يبدأه المستخدم من التطبيق؛ لا نحاول التحايل على قيود أندرويد.
 */
class AkhaliListeningService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private var ready = false
    private val channelId = "akhali_voice"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(20, notification("الأكحلي يستمع للأوامر الصوتية"))
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) startRecognition()
    }

    private fun startRecognition() {
        recognizer?.destroy()
        recognizer = if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        } else SpeechRecognizer.createSpeechRecognizer(this)

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: android.os.Bundle?) {
                val texts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                val heard = texts.firstOrNull()?.trim().orEmpty()
                if (heard.isNotEmpty()) handleSpeech(heard)
                restartSoon()
            }
            override fun onError(error: Int) { restartSoon() }
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            if (Build.VERSION.SDK_INT >= 23) putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        recognizer?.startListening(intent)
    }

    private fun restartSoon() {
        android.os.Handler(mainLooper).postDelayed({ if (!isDestroyed) startRecognition() }, 600)
    }

    private fun handleSpeech(text: String) {
        val normalized = text.lowercase(Locale("ar"))
        if (!normalized.contains("أكحلي") && !normalized.contains("اكحلي")) return
        val command = normalized.replace("أكحلي", "").replace("اكحلي", "").trim()
        val reply = when {
            command.isBlank() -> "نعم، معك الأكحلي. ماذا تريد؟"
            command.contains("من أنت") -> "أنا الأكحلي، مساعدك الشخصي."
            command.contains("توقف") -> "حاضر. أوقف الاستماع الآن."
            else -> "سمعتك: $command. هذه نسخة تجريبية، وسيتم ربط الأوامر بالهاتف في المرحلة التالية."
        }
        speak(reply)
        if (command.contains("توقف")) stopSelf()
    }

    private fun speak(text: String) { if (ready) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "akhali_reply") }
    override fun onInit(status: Int) { ready = status == TextToSpeech.SUCCESS; if (ready) tts.language = Locale("ar") }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "الأكحلي الصوتي", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }
    private fun notification(text: String): Notification =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId).setContentTitle("الأكحلي").setContentText(text).setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        else Notification.Builder(this).setContentTitle("الأكحلي").setContentText(text).setSmallIcon(android.R.drawable.ic_btn_speak_now).build()

    override fun onDestroy() { recognizer?.destroy(); tts.shutdown(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
