package com.akhali.assistant

import android.service.voice.VoiceInteractionService

/**
 * نقطة دخول مساعد النظام.
 * النسخة الإنتاجية ستضيف wake-word محلي + ASR محلي + محرك أوامر + ذاكرة + نظام موافقة للتحديثات.
 */
class AkhaliVoiceService : VoiceInteractionService()
