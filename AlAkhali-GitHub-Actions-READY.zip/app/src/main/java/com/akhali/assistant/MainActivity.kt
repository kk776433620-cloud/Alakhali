package com.akhali.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import java.util.Locale
import android.speech.tts.TextToSpeech

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private val req = 77
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 45, 28, 28) }
        val title = TextView(this).apply { text = "الأكحلي\nمساعدك الشخصي"; textSize = 30f }
        val info = TextView(this).apply {
            text = "الإصدار 0.2.0\n\n• استماع صوتي في الخلفية عند تشغيله\n• يفضّل التعرف على الكلام محليًا عندما يدعمه الهاتف\n• نطق عربي\n• أساس إدارة المكالمات\n• التطوير الذاتي: بموافقتك فقط\n\nلن يعمل إذا كان الهاتف مطفأً بالكامل."
            textSize = 17f; setPadding(0, 20, 0, 20)
        }
        val start = Button(this).apply { text = "🎙️ تشغيل الاستماع"; setOnClickListener { requestAndStart() } }
        val stop = Button(this).apply { text = "⏹ إيقاف الاستماع"; setOnClickListener { stopService(Intent(this@MainActivity, AkhaliListeningService::class.java)) } }
        val test = Button(this).apply { text = "🔊 تجربة صوت الأكحلي"; setOnClickListener { speak("مرحباً، أنا الأكحلي. أنا جاهز لمساعدتك.") } }
        root.addView(title); root.addView(info); root.addView(start); root.addView(stop); root.addView(test)
        setContentView(root)
    }

    private fun requestAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), req)
        else startListening()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == req && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startListening()
    }
    private fun startListening() {
        val intent = Intent(this, AkhaliListeningService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "الأكحلي يعمل الآن", Toast.LENGTH_SHORT).show()
    }
    private fun speak(text: String) { tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "test") }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts.language = Locale("ar") }
    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
