plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.akhali.assistant"; compileSdk = 35
    defaultConfig { applicationId = "com.akhali.assistant"; minSdk = 29; targetSdk = 35; versionCode = 1; versionName = "0.2.0" }
}
